from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import User
from.import models
from urllib.parse import quote
import requests


# Signup View
from django.shortcuts import render, redirect
from .models import User

def signup_view(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = User()
        response = user.signup(email, password)

        if "successfully" in response.lower():
            return redirect('login')  # Redirect to login page on success
        else:
            return render(request, 'signup.html', {'error': response})

    return render(request, 'signup.html')  # Render the signup form for GET request


# Login View
def login_view(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = User()
        is_authenticated = user.authenticate_user(email, password)

        if is_authenticated:
            # Store user session data (including user_id)
            with user.connection.cursor() as cursor:
                cursor.execute("SELECT user_id FROM users WHERE email = %s", (email,))
                result = cursor.fetchone()
                request.session['user_id'] = result['user_id']
                request.session['email'] = email
            return redirect('dashboard')  # Redirect to dashboard on success
        else:
            return render(request, 'login.html', {'error': "Invalid email or password."})

    return render(request, 'login.html')  # Render the login form for GET request

    return render(request, 'login.html')
# Logout View
def logout_view(request):
    request.session.flush()  # Clear session data
    return redirect('login')  # Redirect to login page

def dashboard_view(request):
    if 'user_id' not in request.session:
        return redirect('login')  # Redirect to login if no user_id in session
    
    return render(request, 'home.html')  # Render the dashboard (home page)




def get_ngrok_hostname():
    """
    Fetch the public ngrok hostname from the ngrok API.
    """
    try:
        # ngrok's API runs locally at http://127.0.0.1:4040/api/tunnels
        response = requests.get("http://127.0.0.1:4040/api/tunnels")
        response.raise_for_status()  # Raise an error if the request fails
        data = response.json()

        # Find the public HTTPS tunnel
        for tunnel in data.get("tunnels", []):
            if tunnel["proto"] == "https":
                return tunnel["public_url"]

    except requests.RequestException as e:
        print(f"Error fetching ngrok hostname: {e}")
        return None


def generate_feedback_link(request):
    if 'user_id' not in request.session:
        return redirect('login')  # Ensure the user is logged in

    user_id = request.session.get('user_id')  # Retrieve the logged-in user's ID
    user = User()
    feedback_token = user.generate_feedback_link(user_id)  # Generate feedback link token

    if feedback_token:
        # Dynamically fetch the ngrok hostname
        ngrok_hostname = get_ngrok_hostname()

        if ngrok_hostname:
            # Generate the feedback link using the fetched hostname
            feedback_link = f"{ngrok_hostname}/feedback/{feedback_token}/"
            return render(request, 'feedback_link.html', {'feedback_link': feedback_link})
        else:
            return render(request, 'error.html', {'message': "Failed to fetch ngrok hostname."})
    else:
        return render(request, 'error.html', {'message': "Failed to generate feedback link."})




    
def submit_feedback(request, feedback_token):
    if request.method == "POST":
        # Get selected positive emotions (multiple values can be selected)
        positive_emotions = request.POST.getlist("positive_emotions")

        # Get selected improvement areas (multiple values can be selected)
        improvement_areas = request.POST.getlist("improvement_areas")

        # Get the text feedback
        positive_feedback = request.POST.get("positive_feedback")
        improvement_feedback = request.POST.get("improvement_feedback")

        user = User()
        response = user.submit_feedback(
            feedback_token,
            ", ".join(positive_emotions),  # Convert list of emotions to a comma-separated string
            positive_feedback,
            ", ".join(improvement_areas),  # Convert list of improvement areas to a comma-separated string
            improvement_feedback
        )

        if "successfully" in response.lower():
            return render(request, 'success.html', {'message': response})
        else:
            return render(request, 'error.html', {'message': response})

    return render(request, "submit_feedback.html")  # Render the feedback form for GET request

def view_feedback(request):
    if 'user_id' not in request.session:
        return redirect('login')  # Redirect to login if user is not authenticated

    user_id = request.session.get('user_id')  # Get user_id from the session
    user = User()

    # Fetch the feedback for the user
    feedbacks = user.get_feedback(user_id)

    if feedbacks:
        return render(request, 'view_feedback.html', {'feedbacks': feedbacks})
    else:
        return render(request, 'error.html', {'message': "No feedback found."})

