import pymysql
import uuid
from django.shortcuts import render,redirect
from django.contrib.auth import login, authenticate, logout
def get_database_connection():
    return pymysql.connect(
        host='bxmtfudunwbqvyxzwdm7-mysql.services.clever-cloud.com',
        user='u223amtbmqydnuj3',
        password='Z3aHOabo8ROeUOzKvPjz',
        database='bxmtfudunwbqvyxzwdm7',
        cursorclass=pymysql.cursors.DictCursor
    )

class User:
    def __init__(self):
        self.connection = get_database_connection()

    def authenticate_user(self, email, password):
        """
        Authenticate a user by calling the AuthenticateUser stored procedure.
        """
        try:
            with self.connection.cursor() as cursor:
                # Call the AuthenticateUser stored procedure
                sql = "CALL AuthenticateUser(%s, %s, @is_authenticated)"
                cursor.execute(sql, (email, password))
                
                # Fetch the output parameter
                cursor.execute("SELECT @is_authenticated")
                result = cursor.fetchone()
                return result['@is_authenticated'] == 1  # Convert to boolean
        except Exception as e:
            print("Exception during authentication:", e)
            return False

    def signup(self, email, password):
        """
        Register a new user by calling the InsertUser stored procedure.
        """
        try:
            with self.connection.cursor() as cursor:
                # Call the InsertUser stored procedure
                sql = "CALL InsertUser(%s, %s)"
                cursor.execute(sql, (email, password))
                self.connection.commit()
                return "User registered successfully."
        except pymysql.MySQLError as e:
            # Check for specific MySQL errors (e.g., duplicate email)
            if e.args[0] == 45000:  # Custom signal from InsertUser
                return "Email already registered."
            print("Exception during signup:", e)
            return "User registration failed."
        
    def generate_feedback_link(self, user_id):
        """
        Generate a unique feedback link for the user and save it to the feedback_links table.
        """
        try:
            feedback_token = str(uuid.uuid4())  # Generate unique link token
            with self.connection.cursor() as cursor:
                sql = "INSERT INTO feedback_links (user_id, link_token) VALUES (%s, %s)"
                cursor.execute(sql, (user_id, feedback_token))
                self.connection.commit()
                return feedback_token
        except Exception as e:
            print("Exception during feedback link generation:", e)
            return None

    def submit_feedback(self, link_token, positive_emotions, positive_feedback, improvement_areas, improvement_feedback):
        """
        Submit feedback using a feedback link token.
        """
        try:
            with self.connection.cursor() as cursor:
                # Retrieve link ID using the feedback token
                sql_get_link = "SELECT link_id FROM feedback_links WHERE link_token = %s"
                cursor.execute(sql_get_link, (link_token,))
                link = cursor.fetchone()
                if not link:
                    return "Invalid feedback link."

                # Insert feedback into the feedback table
                sql_insert_feedback = """
                    INSERT INTO feedback 
                    (link_id, positive_emotions, positive_feedback, improvement_areas, improvement_feedback)
                    VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(sql_insert_feedback, (link['link_id'], positive_emotions, positive_feedback, improvement_areas, improvement_feedback))
                self.connection.commit()
                return "Feedback submitted successfully. Thank You.!!"
        except Exception as e:
            print("Exception during feedback submission:", e)
            return "Feedback submission failed."

    def get_feedback(self, user_id):
        """
        Retrieve all feedback associated with a user's feedback links.
        """
        try:
            with self.connection.cursor() as cursor:
                sql = """
                    SELECT f.positive_emotions, f.positive_feedback, f.improvement_areas, f.improvement_feedback, f.create_at
                    FROM feedback f
                    INNER JOIN feedback_links fl ON f.link_id = fl.link_id
                    WHERE fl.user_id = %s
                """
                cursor.execute(sql, (user_id,))
                feedbacks = cursor.fetchall()
                return feedbacks
        except Exception as e:
            print("Exception during feedback retrieval:", e)
            return []